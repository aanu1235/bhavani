package com.example.demo6969;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo6969Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo6969Application.class, args);
	}

}
